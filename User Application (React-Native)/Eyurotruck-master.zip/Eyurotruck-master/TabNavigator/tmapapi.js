import React, { Component } from "react";
import {View,Text,TouchableOpacity,TextInput,StyleSheet} from "react-native";

export default class CarCheckTab extends React.Component {
    
}

<script></script>